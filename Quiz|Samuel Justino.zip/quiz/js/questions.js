var questions = [{
  question: "Tecnologia é ____ e  não ____.",
  choices: ['começo - fim', 'fim - começo', 'meio - fim', 'começo - meio'],
  correctAnswer: 2,
  answerLocation: '"https://tinyurl.com/y7k3q3gw"'
}, {
  question: "Do que trata Sistemas de Informação?",
  choices: ['Hardware e Software','Dados','Pessoas e processos','Todas as alternativas'],
  correctAnswer: 3,
  answerLocation: '"http://saiadolugar.com.br/sistema-de-informacao/"'
}, {
  question: "Computação Evolucionária é parte da biologia?",
  choices: ['Sim, e é essencial em pesquisas', 'Não, e não há relação alguma', 'Sim, mas é muito pouco utilizada', 'Não, mas pode ser aplicada em pesquisas'],
  correctAnswer: 3,
  answerLocation: '"https://tinyurl.com/yad6h6bc"'
}, {
  question: "Qual é a língua de programação considerada \" a língua do mercado\"?",
  choices: ['JAVA', 'PHP', 'Kotlin', 'JavaScript'],
  correctAnswer: 0,
  answerLocation: '"https://tinyurl.com/ya77bf5k"'
}, {
  question: "Quem criou a linguagem de programação \"Python\"?",
  choices: ['Gabe Newel', 'Guido Van Rossum', 'Dennis Ritchie', 'James Gosling'],
  correctAnswer: 1,
  answerLocation: '"http://mindbending.org/pt/a-historia-do-python"'
}, {
  question: "Quem foram Diffie e Hellman?",
  choices: ['Fundadores da linguagem de programação JAVA', 'Autores de um importante artigo sobre criptografia', 'Os primeiros programadores da história', 'Criminosos que ficaram famosos por sua criptografia'],
  correctAnswer: 1,
  answerLocation: '"https://tinyurl.com/y8an6ro9"'
}, {
  question: "Em que se inspira a Computação Evolucionária?",
  choices: ['Na evolução do uso da computação nos últimos anos','Desenvolvimento do ser humano ao longo dos tempos','Ciclo de vida humano','Na seleção natural'],
  correctAnswer: 3,
  answerLocation: '"https://tinyurl.com/yad6h6bc"'
}, {
  question: "O que significa a sigla \"POO\"?",
  choices: ['Programação Orientada a Ocultismo', 'Programação Ou Objetos', 'Programação Orientada a Objetos', 'Nenhuma das opções'],
  correctAnswer: 2,
  answerLocation: '"https://tinyurl.com/y9q5uers"'
}, {
  question: "Qual comando mostra o \"Zen do Python\" no terminal?",
  choices: ['Import This', 'Input This', 'Insert This', 'Output This'],
  correctAnswer: 0,
  answerLocation: '"https://www.python.org/dev/peps/pep-0020/"'
}, {
  question: "Qual desses é um importante modelo de criptografia?",
  choices: ['RSA', 'CCK', 'HideInfo', 'Botchain'],
  correctAnswer: 0,
  answerLocation: '"https://tinyurl.com/y8an6ro9"'
}];
